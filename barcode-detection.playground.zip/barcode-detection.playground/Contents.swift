import UIKit
import Vision

//step 11 “Create an extension on VNImageRequestHandler with a convenience initializer”  “A VNImageRequestHandler is used to work with images in Apple’s Vision framework. It acts as a handle for an image that we’re working with, so we don’t need to mess with the real definitive copy of an image.”

extension VNImageRequestHandler {
    convenience init?(uiImage: UIImage) {
        guard let cgImage = uiImage.cgImage else { return nil }
        let orientation = uiImage.cgImageOrientation

        self.init(cgImage: cgImage, orientation: orientation)
    }
}

//step 12 “This queues up requests for the VNImageRequestHandler: it allows us to push things into Vision to be processed”

extension VNRequest {
    func queueFor(image: UIImage,  completion: @escaping ([Any]?) -> ()) {
        DispatchQueue.global().async {
            if let handler = VNImageRequestHandler(uiImage: image) {
                try? handler.perform([self])
                completion(self.results)
            } else {
                return completion(nil)
            }
        }
    }
}

//step 13 “Add an extension on UIImage, and a function to dectect rectangles (just in case we want to look for those) and to detect barcodes”
//“Both of these functions work the same way: they add a function to UIImage that lets us ask for barcodes or rectangles. When called, the function creates a request with Vision and looks for the type of thing we’re asking for.”

extension UIImage {
    func detectRectangles(
        completion: @escaping ([VNRectangleObservation]) -> ()) {

        let request = VNDetectRectanglesRequest()
        request.minimumConfidence = 0.8
        request.minimumAspectRatio = 0.3
        request.maximumObservations = 3

        request.queueFor(image: self) { result in
            completion(result as? [VNRectangleObservation] ?? [])
        }
    }

    func detectBarcodes(
        types symbologies: [VNBarcodeSymbology] = [.QR],
        completion: @escaping ([VNBarcodeObservation]) ->()) {

        let request = VNDetectBarcodesRequest()
        request.symbologies = symbologies

        request.queueFor(image: self) { result in
            completion(result as? [VNBarcodeObservation] ?? [])
        }
    }

    // can also detect human figures, animals, the horizon, all sorts of
    // things with inbuilt Vision functions
}

//test time!! -- barcode
// YOU CAN CHANGE THE IMAGE LOCATION
let barcodeTestImage = UIImage(named: "test.png")!

barcodeTestImage.detectBarcodes { barcodes in
    for barcode in barcodes {
        print("Detected barcode data: \(barcode.payloadStringValue ?? "None")")
    }
}
